#pragma once
typedef struct poly
{
	int specialty;
	int qualification;
	char* fio;
}lib;